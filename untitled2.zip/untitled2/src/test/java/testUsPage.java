import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static java.lang.Thread.sleep;


public class testUsPage {
    private String urlMain = "file:///D:/my_prac/site%201.1.2/main%20page/index.html";
    private String urlUs = "file:///D:/my_prac/site%201.1.2/about%20us/index.html";
    private String urlContacts = "file:///D:/my_prac/site%201.1.2/contact/index.html";
    private String urlVk = "https://vk.com/";
    private String urlYt = "https://www.youtube.com/";
    private String urlTg = "https://t.me/cadr_hackerspace";

    WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

    }

    @After
    public void close() {
        driver.quit();
    }


    // test navbar

    @Test
    public void testUsPageToMainPageLogo() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.id("toMain")).click();
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToMainPage() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.xpath("//*[@id=\"navbarNavAltMarkup\"]/div/a[1]")).click();
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToUs() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.xpath("//*[@id=\"navbarNavAltMarkup\"]/div/a[2]")).click();
        Assert.assertEquals(urlUs, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToContacts() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.className("contact")).click();
        Assert.assertEquals(urlContacts, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToInfOne() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.id("toMainFooter")).click();
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }
    @Test
    public void testUsPageToInfTwo() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.xpath("/html/body/section/div/div/div[1]/ul/li[2]/a")).click();
        Assert.assertEquals(urlUs, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToInfThree() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.xpath("/html/body/section/div/div/div[1]/ul/li[3]/a")).click();
        Assert.assertEquals(urlContacts, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToVk() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.className("vk")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlVk, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToYt() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.className("yt")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlYt, driver.getCurrentUrl());
    }

    @Test
    public void testUsPageToTg() throws InterruptedException {
        driver.navigate().to(urlUs);
        driver.findElement(By.className("tg")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlTg, driver.getCurrentUrl());
    }
}
