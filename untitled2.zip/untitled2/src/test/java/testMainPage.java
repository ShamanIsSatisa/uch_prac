import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import static java.lang.Thread.sleep;


public class testMainPage {
    private String urlMain = "file:///D:/my_prac/site%201.1.2/main%20page/index.html";
    private String urlUs = "file:///D:/my_prac/site%201.1.2/about%20us/index.html";
    private String urlContacts = "file:///D:/my_prac/site%201.1.2/contact/index.html";
    private String urlVk = "https://vk.com/";
    private String urlYt = "https://www.youtube.com/";
    private String urlTg = "https://t.me/cadr_hackerspace";

    WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

    }

    @After
    public void close() {
        driver.quit();
    }


    // test navbar
    @Test
    public void testMainPageToMainPageLogo() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.xpath("/html/body/nav/div/a")).click();
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToMainPage() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("toMain")).click();
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToUs() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.xpath("//*[@id=\"navbarNavAltMarkup\"]/div/a[2]")).click();
        Assert.assertEquals(urlUs, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToContacts() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.className("contact")).click();
        Assert.assertEquals(urlContacts, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToInfOne() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("toMainFooter")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }
    @Test
    public void testMainPageToInfTwo() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.xpath("/html/body/section[2]/div/div/div[1]/ul/li[2]/a")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlUs, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToInfThree() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.xpath("/html/body/section[2]/div/div/div[1]/ul/li[3]/a")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlContacts, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToVk() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.className("vk")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlVk, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToYt() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.className("yt")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlYt, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageToTg() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.className("tg")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlTg, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageNegativeTestOne() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("1")).sendKeys(Keys.ENTER);
        WebElement mebel = driver.findElement(By.id("1"));
        mebel.getText();
        Assert.assertEquals(mebel, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageNegativeTestTwo() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("2")).sendKeys(Keys.ENTER);
        WebElement lest = driver.findElement(By.id("2"));
        lest.getText();
        Assert.assertEquals(lest, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageNegativeTestThree() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("3")).sendKeys(Keys.ENTER);
        WebElement st = driver.findElement(By.id("3"));
        st.getText();
        Assert.assertEquals(st, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageNegativeTestFour() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("4")).sendKeys(Keys.ENTER);
        WebElement desk = driver.findElement(By.id("4"));
        desk.getText();
        Assert.assertEquals(desk, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageNegativeTestFive() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("5")).sendKeys(Keys.ENTER);
        WebElement inter = driver.findElement(By.id("5"));
        inter.getText();
        Assert.assertEquals(inter, driver.getCurrentUrl());
    }

    @Test
    public void testMainPageNegativeTestSix() throws InterruptedException {
        driver.navigate().to(urlMain);
        driver.findElement(By.id("6")).sendKeys(Keys.ENTER);
        WebElement peregorod = driver.findElement(By.id("6"));
        peregorod.getText();
        Assert.assertEquals(peregorod, driver.getCurrentUrl());
    }

    @Test
    public void testCarousel1()
    {
        driver.navigate().to(urlMain);
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleCaptions\"]/button[2]/span[1]"));
        Lo.click();
        var expectedResult = driver.findElement(By.id("img2"));
        var actualResult = driver.findElement(By.id("img2"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarousel2()
    {
        driver.navigate().to(urlMain);
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleCaptions\"]/button[2]/span[1]"));
        Lo.click();
        var expectedResult = driver.findElement(By.id("img3"));
        var actualResult = driver.findElement(By.id("img3"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarousel3()
    {
        driver.navigate().to(urlMain);
        WebElement Ly = driver.findElement(By.xpath("//*[@id=\"carouselExampleCaptions\"]/button[2]/span[1]"));
        Ly.click();
        var expectedResult = driver.findElement(By.id("img1"));
        var actualResult = driver.findElement(By.id("img1"));
        Assert.assertEquals(expectedResult, actualResult);
    }
}
