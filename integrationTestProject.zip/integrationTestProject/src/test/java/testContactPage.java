import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.image.Kernel;

import static java.lang.Thread.sleep;


public class testContactPage {
    private String urlMain = "file:///D:/my_prac/site%201.1.2/main%20page/index.html";
    private String urlUs = "file:///D:/my_prac/site%201.1.2/about%20us/index.html";
    private String urlContacts = "file:///D:/my_prac/site%201.1.2/contact/index.html";
    private String urlVk = "https://vk.com/";
    private String urlYt = "https://www.youtube.com/";
    private String urlTg = "https://t.me/cadr_hackerspace";

    WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

    }

    @After
    public void close() {
        driver.quit();
    }


    // test navbar

    @Test
    public void testContactPageToMainPageLogo() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.xpath("/html/body/nav/div/a")).click();
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToMainPage() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.id("toMain")).click();
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToUs() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.xpath("//*[@id=\"navbarNavAltMarkup\"]/div/a[2]")).click();
        Assert.assertEquals(urlUs, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToContacts() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.className("contact")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlContacts, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToInfOne() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.id("toMainFooter")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlMain, driver.getCurrentUrl());
    }
    @Test
    public void testContactPageToInfTwo() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.xpath("/html/body/section/div/div/div[1]/ul/a[2]")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlUs, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToInfThree() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.xpath("/html/body/section/div/div/div[1]/ul/a[3]")).sendKeys(Keys.ENTER);
        Assert.assertEquals(urlContacts, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToVk() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.className("vk")).click();
        Assert.assertEquals(urlVk, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToYt() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.className("yt")).click();
        Assert.assertEquals(urlYt, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToTg() throws InterruptedException {
        driver.navigate().to(urlContacts);
        driver.findElement(By.className("tg")).click();
        Assert.assertEquals(urlTg, driver.getCurrentUrl());
    }

    @Test
    public void testContactPageToSend() throws InterruptedException {
        driver.navigate().to(urlContacts);
        WebElement sendName = driver.findElement(By.xpath("//*[@id=\"exampleInputName\"]"));
        sendName.sendKeys("MyName");
        String name = sendName.getAttribute("value");
        Assert.assertEquals("MyName",name);
        WebElement sendFeed = driver.findElement(By.xpath("//*[@id=\"exampleInputComm\"]"));
        sendFeed.sendKeys("Feedback");
        String feed = sendFeed.getAttribute("value");
        Assert.assertEquals("Feedback",feed);
        driver.findElement(By.xpath("//*[@id=\"exampleInputName\"]")).sendKeys("MyName");
        driver.findElement(By.className("send")).sendKeys(Keys.ENTER);
        Assert.assertEquals("Спасибо за отзыв", driver.getCurrentUrl());
    }
}
